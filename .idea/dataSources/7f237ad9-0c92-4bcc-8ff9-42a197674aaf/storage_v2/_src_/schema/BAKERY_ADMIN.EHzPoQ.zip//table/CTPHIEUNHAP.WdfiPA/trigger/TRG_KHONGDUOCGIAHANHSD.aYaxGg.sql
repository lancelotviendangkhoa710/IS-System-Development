create trigger TRG_KHONGDUOCGIAHANHSD
    before update
    on CTPHIEUNHAP
    for each row
BEGIN
    IF :NEW.HanSuDung > :OLD.HanSuDung THEN
        RAISE_APPLICATION_ERROR(-20002,'HAN_SU_DUNG_KHONG_THE_CHINH_SUA');

    end if;
end;
/

