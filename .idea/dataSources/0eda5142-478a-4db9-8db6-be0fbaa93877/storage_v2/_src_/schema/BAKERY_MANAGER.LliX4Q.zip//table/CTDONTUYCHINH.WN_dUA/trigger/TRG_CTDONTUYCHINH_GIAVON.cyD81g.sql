create trigger TRG_CTDONTUYCHINH_GIAVON
    before insert
    on CTDONTUYCHINH
    for each row
BEGIN
    :NEW.DONGIAVON := FUNC_TinhGiaVonDong(:NEW.MASP);
END;
/

