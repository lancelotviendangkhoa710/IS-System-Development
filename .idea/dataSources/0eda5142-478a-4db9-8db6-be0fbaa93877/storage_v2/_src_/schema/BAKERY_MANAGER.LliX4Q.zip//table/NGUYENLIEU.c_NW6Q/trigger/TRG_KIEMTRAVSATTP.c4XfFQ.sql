create trigger TRG_KIEMTRAVSATTP
    before insert or update
    on NGUYENLIEU
    for each row
BEGIN
    IF :NEW.DATCHUANVSATTP = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'NGUYEN_LIEU_KHONG_DAT_CHUAN: Nguyen lieu khong dat chuan, cam nhap kho');
    END IF;
END;
/

