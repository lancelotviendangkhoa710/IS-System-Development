create trigger TRG_CAMXOAKETOAN_HOADON
    before delete
    on HOADON
    for each row
BEGIN
    RAISE_APPLICATION_ERROR(-20003, 'VI_PHAM_KE_TOAN: Cam tuyet doi xoa vat ly chung tu tai chinh. Vui long su dung chuc nang Huy Don!');
END;
/

