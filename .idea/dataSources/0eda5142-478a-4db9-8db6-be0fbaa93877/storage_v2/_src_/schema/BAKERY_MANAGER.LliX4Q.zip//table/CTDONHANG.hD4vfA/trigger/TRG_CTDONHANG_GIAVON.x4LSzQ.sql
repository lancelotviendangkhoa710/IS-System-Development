create trigger TRG_CTDONHANG_GIAVON
    before insert
    on CTDONHANG
    for each row
BEGIN
    :NEW.DONGIAVON := FUNC_TinhGiaVonDong(:NEW.MASP);
END;
/

